import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pixel Puzzler',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blueAccent, Colors.purpleAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              padding: EdgeInsets.symmetric(horizontal: 50, vertical: 20),
              textStyle: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            child: Text('Boshlash'),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LevelSelectionPage()),
              );
            },
          ),
        ),
      ),
    );
  }
}

class LevelSelectionPage extends StatefulWidget {
  @override
  _LevelSelectionPageState createState() => _LevelSelectionPageState();
}

class _LevelSelectionPageState extends State<LevelSelectionPage> {
  int currentLevel = 1;

  void _updateCurrentLevel(int newLevel) {
    setState(() {
      if (newLevel > currentLevel) {
        currentLevel = newLevel;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Bosqichlar'),
      ),
      body: GridView.builder(
        padding: EdgeInsets.all(16),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: 5,
        itemBuilder: (context, index) {
          int level = index + 1;
          bool isUnlocked = level <= currentLevel;

          return GestureDetector(
            onTap: isUnlocked
                ? () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => GamePage(
                          level: level,
                          gridSize: 3 + level - 1,
                          onLevelComplete: (newLevel) {
                            _updateCurrentLevel(newLevel);
                            Navigator.pop(context);
                          },
                        ),
                      ),
                    );
                  }
                : null,
            child: Container(
              decoration: BoxDecoration(
                color: isUnlocked ? Colors.green : Colors.grey,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 5,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Bosqich $level',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class GamePage extends StatefulWidget {
  final int level;
  final int gridSize;
  final Function(int) onLevelComplete;

  GamePage({
    required this.level,
    required this.gridSize,
    required this.onLevelComplete,
  });

  @override
  _GamePageState createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  late List<int> numbers;
  late List<int> shuffledNumbers;
  bool isSolved = false;

  @override
  void initState() {
    super.initState();
    _initializeNumbers();
    _shuffleNumbers();
  }

  void _initializeNumbers() {
    numbers =
        List.generate(widget.gridSize * widget.gridSize, (index) => index + 1);
  }

  void _shuffleNumbers() {
    shuffledNumbers = List.from(numbers);
    shuffledNumbers.shuffle();
  }

  void _onTileTap(int index) {
    if (isSolved) return;

    int emptyIndex = shuffledNumbers.indexOf(widget.gridSize * widget.gridSize);
    if ((index - emptyIndex).abs() == 1 ||
        (index - emptyIndex).abs() == widget.gridSize) {
      setState(() {
        shuffledNumbers[emptyIndex] = shuffledNumbers[index];
        shuffledNumbers[index] = widget.gridSize * widget.gridSize;
        _checkIfSolved();
      });
    }
  }

  void _checkIfSolved() {
    if (List.generate(widget.gridSize * widget.gridSize, (index) => index + 1)
            .toString() ==
        shuffledNumbers.toString()) {
      setState(() {
        isSolved = true;
      });
    }
  }

  void _help() {
    setState(() {
      shuffledNumbers = List.from(numbers);
      _checkIfSolved();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('bosqich ${widget.level}'),
      ),
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              padding: EdgeInsets.all(16),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: widget.gridSize,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemCount: widget.gridSize * widget.gridSize,
              itemBuilder: (context, index) {
                int number = shuffledNumbers[index];
                return GestureDetector(
                  onTap: number != widget.gridSize * widget.gridSize
                      ? () => _onTileTap(index)
                      : null,
                  child: Container(
                    alignment: Alignment.center,
                    color: Colors.blue,
                    child: number != widget.gridSize * widget.gridSize
                        ? Text(
                            '$number',
                            style: TextStyle(fontSize: 24, color: Colors.white),
                          )
                        : SizedBox.shrink(),
                  ),
                );
              },
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton(
                onPressed: _help,
                child: Text('Yordam'),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('Bosh Menu'),
              ),
            ],
          ),
          if (isSolved)
            ElevatedButton(
              onPressed: () {
                widget.onLevelComplete(widget.level + 1);
              },
              child: Text('Keyingi'),
            ),
        ],
      ),
    );
  }
}
