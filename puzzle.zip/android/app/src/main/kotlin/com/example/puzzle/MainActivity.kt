package com.example.puzzle

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
